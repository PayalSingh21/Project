python train.py --log_dir log1 --test_area 1
python train.py --log_dir log2 --test_area 2
python train.py --log_dir log3 --test_area 3
python train.py --log_dir log4 --test_area 4
python train.py --log_dir log5 --test_area 5
python train.py --log_dir log6 --test_area 6