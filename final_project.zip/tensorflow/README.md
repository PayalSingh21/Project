# Dynamic Graph CNN for Learning on Point Clouds (TensorFlow)

## Point Cloud Classification
* Run the training script:

``` bash
python train.py
```

* Run the evaluation script after training finished:

``` bash
python evalutate.py

```
